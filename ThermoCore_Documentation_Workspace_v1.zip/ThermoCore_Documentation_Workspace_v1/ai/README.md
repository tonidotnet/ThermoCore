# ThermoCore AI Workspace

Load files in this order:

1. `AI_CONTEXT.md`
2. `../docs/00_Project/MASTER_INDEX.md`
3. `../docs/00_Project/DOCUMENT_INVENTORY.md`
4. `../docs/00_Project/IMPLEMENTATION_PROGRESS.md`
5. `../docs/07_ProjectManagement/18_CodingRules.md`
6. relevant engineering documents
7. JSON graphs

Files marked as `Planned` or `Local replacement required` must not be used as authoritative implementation specifications.
