# ThermoCore Documentation Package 02

This package contains the next grouped documentation set.

## Files

```text
docs/04_Simulation/14_ControlSystem.md
docs/04_Simulation/15_SystemTopology.md
docs/04_Simulation/16_SimulationEngine.md
docs/04_Simulation/28_WeatherModel.md
docs/06_Testing/22_TestStrategy.md
```

## Installation

Extract this ZIP over `ThermoCore_Documentation_Workspace_v1`.

These files are intended to replace the corresponding planned placeholder files.

## Suggested review order

1. `16_SimulationEngine.md`
2. `22_TestStrategy.md`
3. `15_SystemTopology.md`
4. `14_ControlSystem.md`
5. `28_WeatherModel.md`

## Next grouped package

Recommended product and data group:

```text
19_WebApi.md
20_BlazorWeb.md
21_DataModel.md
29_ResultFormats.md
30_Deployment.md
```
